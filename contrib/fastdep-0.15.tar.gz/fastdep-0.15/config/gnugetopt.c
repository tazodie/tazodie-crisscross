#include <unistd.h>

int main(int argc, int argv)
{
	return getopt_long(argc,argv,0,0,0);
}
