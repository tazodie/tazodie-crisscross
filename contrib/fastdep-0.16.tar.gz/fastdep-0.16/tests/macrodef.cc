#define BUFSIZE 1001

#if BUFSIZE==1001
#include "a.h"
#endif

#if BUFSIZE==1000
#include "b.h"
#endif
