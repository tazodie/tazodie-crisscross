#ifndef _SYS_CDEFS_H
#define _SYS_CDEFS_H	1234

#include "features.h"

#endif
