#ifndef symbol		/* some comment */
#include "a.h"
#endif
