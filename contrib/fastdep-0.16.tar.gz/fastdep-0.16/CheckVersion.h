#ifndef CHECKVERSION_3DBA9B36642F541B_H_
#define CHECKVERSION_3DBA9B36642F541B_H_

#define FASTDEP_VERSION_MAJOR 0
#define FASTDEP_VERSION_MINOR 16

#include <string>

int atLeastVersion(const std::string& aVersion);

#endif

